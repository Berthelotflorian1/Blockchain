const ethers = require('ethers');
const provider = ethers.getDefaultProvider(); // homstead (mainnet)

let abi = [
    "event Birth(address owner, uint256 BATId, uint256 matronId, uint256 sireId, uint256 genes)"
];
let contractAddress = "0x0D8775F648430679A709E98d2b0Cb6250d2887EF"; // Changement du contract adress par celui du Basic Attention Token (BAT)
let contract = new ethers.Contract(contractAddress, abi, provider);

contract.on("Birth", (owner,BATId,matronId,sireId,genes,event) => { // Modification des noms de variables pour correspondre au nouveau token recherché -> BAT
    console.log("# block # : " + event.blockNumber);
    console.log("# Owner : " + owner);
    console.log("# BATId : " + BATId)
});